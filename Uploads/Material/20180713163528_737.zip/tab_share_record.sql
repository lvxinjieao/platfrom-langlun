/*
Navicat MySQL Data Transfer

Source Server         : testh55
Source Server Version : 50557
Source Host           : 121.43.196.29:3306
Source Database       : testh55_vlcms_c

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2018-06-08 17:32:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tab_share_record
-- ----------------------------
DROP TABLE IF EXISTS `tab_share_record`;
CREATE TABLE `tab_share_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invite_id` int(11) DEFAULT NULL COMMENT '邀请人ID',
  `invite_account` varchar(255) DEFAULT NULL COMMENT '邀请人账号',
  `user_id` int(11) DEFAULT NULL COMMENT '被邀请人ID',
  `user_account` varchar(255) DEFAULT NULL COMMENT '被邀请人账号',
  `create_time` int(11) DEFAULT NULL,
  `award_coin` int(11) DEFAULT NULL COMMENT '奖励平台币',
  `order_number` varchar(255) DEFAULT '' COMMENT '订单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tab_share_record
-- ----------------------------
