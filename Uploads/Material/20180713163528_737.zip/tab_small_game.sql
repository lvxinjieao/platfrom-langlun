/*
Navicat MySQL Data Transfer

Source Server         : testh55
Source Server Version : 50557
Source Host           : 121.43.196.29:3306
Source Database       : testh55_vlcms_c

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2018-06-08 17:27:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tab_small_game
-- ----------------------------
DROP TABLE IF EXISTS `tab_small_game`;
CREATE TABLE `tab_small_game` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `game_name` varchar(30) DEFAULT NULL COMMENT '游戏名称',
  `sort` int(10) unsigned DEFAULT '1' COMMENT '排序',
  `theme` varchar(30) NOT NULL COMMENT '首字母',
  `short` varchar(20) DEFAULT NULL COMMENT '游戏简写',
  `scan_num` int(11) DEFAULT '0' COMMENT '扫码次数',
  `icon` int(11) DEFAULT NULL COMMENT '图标',
  `appsecret` varchar(50) DEFAULT '' COMMENT '小程序密钥',
  `appid` varchar(30) DEFAULT '' COMMENT '小程序appid',
  `page_path` varchar(100) DEFAULT '' COMMENT '小程序路径',
  `url` varchar(255) DEFAULT '' COMMENT '备用网址',
  `thumbnail` varchar(100) DEFAULT '0' COMMENT '缩略图',
  `qrcode` int(11) DEFAULT '0' COMMENT '小程序码',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态 1显示 0关闭',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) DEFAULT '0' COMMENT '更新时间',
  `qrcode_time` int(11) NOT NULL,
  `qrcodeurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='游戏表';

-- ----------------------------
-- Records of tab_small_game
-- ----------------------------
INSERT INTO `tab_small_game` VALUES ('3', '桔子互动', '8', 'J', 'JZHD', '29', '359', 'AppSecret', 'wx5c410c67c7a9d368', 'pages/index/index', '网址', '262', '534', '1', '1527845859', '0', '1528444101', 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQGt7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyNm9kdGQ4YnBjZmwxbDVNMHhyY3EAAgTFNBpbAwSAOyYA');
INSERT INTO `tab_small_game` VALUES ('16', '猎魂传说', '1', 'L', 'LHCS', '0', '493', '55', '132', '11', '', '493', '493', '1', '1528447275', '1528447289', '1528447290', 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQEY7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyYWhKc2NyYnBjZmwxbVdZMDFyY1oAAgQ6QRpbAwSAOyYA');
INSERT INTO `tab_small_game` VALUES ('17', '猎魔传说', '1', '', 'LMCS', '0', '428', '123', '12', '123', '', '428', '428', '1', '1528448234', '1528448234', '1528448235', 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQEm8DwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyLTVIN2QzYnBjZmwxcEgwMHhyY2kAAgTrRBpbAwSAOyYA');
INSERT INTO `tab_small_game` VALUES ('18', '王者荣耀', '1', '', 'WZRY', '0', '458', '12312', '1231', '312', '', '458', '458', '1', '1528448625', '1528448625', '1528448626', 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQFC7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyY3A2VmNlYnBjZmwxck8xME5yYzUAAgRyRhpbAwSAOyYA');
INSERT INTO `tab_small_game` VALUES ('15', '游脉通', '1', 'Y', 'YMT', '0', '494', 'd3d269d7d8ba9f6a23f2066be2a0434c ', 'wx55ae51207165eae8', 'pages/login/login', '', '495', '495', '1', '1528443128', '0', '1528443128', 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQG87zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyeFE0N2QtYnBjZmwxbFVJMHhyY2sAAgT4MBpbAwSAOyYA');
