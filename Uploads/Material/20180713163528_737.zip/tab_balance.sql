/*
Navicat MySQL Data Transfer

Source Server         : testh55
Source Server Version : 50557
Source Host           : 121.43.196.29:3306
Source Database       : testh55_vlcms_c

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2018-06-08 17:27:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tab_balance
-- ----------------------------
DROP TABLE IF EXISTS `tab_balance`;
CREATE TABLE `tab_balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `promote_id` int(11) DEFAULT '0' COMMENT '渠道ID',
  `promote_account` varchar(30) CHARACTER SET utf8 DEFAULT '' COMMENT '渠道账号',
  `balance` double(11,2) DEFAULT '0.00' COMMENT '余额',
  `money` double(11,2) DEFAULT '0.00' COMMENT '充值数额',
  `recharge_account` varchar(50) CHARACTER SET utf8 DEFAULT '' COMMENT '充值账户',
  `recharge_type` tinyint(2) DEFAULT '1' COMMENT '支付方式(1:支付宝,2:微信(扫码)3微信app 4 威富通 5聚宝云 6竣付通',
  `pay_status` tinyint(2) DEFAULT '0' COMMENT '支付状态 0失败 1成功',
  `order_number` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '订单号',
  `pay_order_number` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '支付订单号',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `recharge_id` int(11) DEFAULT '0' COMMENT '充值ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COMMENT='平台币充值记录';

-- ----------------------------
-- Records of tab_balance
-- ----------------------------
INSERT INTO `tab_balance` VALUES ('1', '4', 'asdasd', '593.90', '1.00', 'asdasd', '1', '0', '', 'TB_20180518163706Q28j', '1526632626', '4');
INSERT INTO `tab_balance` VALUES ('2', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180518163716rNo5', '1526632636', '4');
INSERT INTO `tab_balance` VALUES ('3', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180518163721KqgI', '1526632641', '4');
INSERT INTO `tab_balance` VALUES ('4', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180518163725YqNG', '1526632645', '4');
INSERT INTO `tab_balance` VALUES ('5', '4', 'asdasd', '593.90', '1.00', 'asdasd', '1', '0', '', 'TB_201805181637346cuF', '1526632654', '4');
INSERT INTO `tab_balance` VALUES ('6', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_201805181637393adg', '1526632659', '4');
INSERT INTO `tab_balance` VALUES ('7', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_201805181637438SXB', '1526632663', '4');
INSERT INTO `tab_balance` VALUES ('8', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180518163753Wr2O', '1526632673', '4');
INSERT INTO `tab_balance` VALUES ('9', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180518163914myrS', '1526632754', '4');
INSERT INTO `tab_balance` VALUES ('10', '4', 'asdasd', '593.90', '1.00', 'asdasd', '1', '0', '', 'TB_20180519091938J4i7', '1526692778', '4');
INSERT INTO `tab_balance` VALUES ('11', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180519091949MVMg', '1526692789', '4');
INSERT INTO `tab_balance` VALUES ('12', '4', 'asdasd', '593.90', '1.00', 'asdasd', '2', '0', '', 'TB_20180519093625jL4J', '1526693785', '4');
INSERT INTO `tab_balance` VALUES ('13', '20', '18652169031', '0.00', '10.00', '18652169031', '1', '0', '', 'TB_201805251522183Ayx', '1527232938', '20');
INSERT INTO `tab_balance` VALUES ('14', '20', '18652169031', '0.00', '1.00', '18652169031', '1', '0', '', 'TB_20180525152300DwJ6', '1527232980', '20');
INSERT INTO `tab_balance` VALUES ('15', '20', '18652169031', '0.00', '1.00', '18652169031', '1', '0', '', 'TB_201805251539504ZAT', '1527233990', '20');
INSERT INTO `tab_balance` VALUES ('16', '20', '18652169031', '0.00', '1.00', '18652169031', '1', '1', '', 'TB_20180602141725Qa0H', '1527920245', '20');
INSERT INTO `tab_balance` VALUES ('17', '3', 'zhaojing', '24.10', '1.00', 'zhaojing', '2', '0', '', 'TB_20180604161309Lkgp', '1528099989', '3');
INSERT INTO `tab_balance` VALUES ('18', '3', 'zhaojing', '1.00', '1.00', '18652169031', '1', '0', '', 'TB_20180604174554na5v', '1528105554', '20');
INSERT INTO `tab_balance` VALUES ('19', '20', '18652169031', '1.00', '1.00', '18652169031', '1', '0', '', 'TB_20180605134742KPB5', '1528177662', '20');
INSERT INTO `tab_balance` VALUES ('20', '20', '18652169031', '1.00', '1.00', '18652169031', '2', '0', '', 'TB_20180605134808JfZC', '1528177688', '20');
INSERT INTO `tab_balance` VALUES ('21', '20', '18652169031', '1.00', '1.00', '18652169031', '1', '0', '', 'TB_20180605135557lhJ9', '1528178157', '20');
INSERT INTO `tab_balance` VALUES ('22', '16', 'z123123', '0.00', '1.00', 'z123123', '1', '0', '', 'TB_20180605135718hrY8', '1528178238', '16');
INSERT INTO `tab_balance` VALUES ('23', '16', 'z123123', '0.00', '1.00', 'z123123', '1', '0', '', 'TB_20180605135741ydFh', '1528178261', '16');
INSERT INTO `tab_balance` VALUES ('24', '16', 'z123123', '0.00', '0.01', 'z123123', '1', '0', '', 'TB_20180605135804qa4v', '1528178284', '16');
INSERT INTO `tab_balance` VALUES ('25', '20', '18652169031', '1.00', '0.01', '18652169031', '1', '1', '', 'TB_201806051400021uL7', '1528178402', '20');
INSERT INTO `tab_balance` VALUES ('26', '20', '18652169031', '1.01', '0.01', '18652169031', '2', '0', '', 'TB_20180605140049lN6I', '1528178449', '20');
INSERT INTO `tab_balance` VALUES ('27', '20', '18652169031', '1.01', '0.01', '18652169031', '2', '0', '', 'TB_20180605140132bw0a', '1528178492', '20');
INSERT INTO `tab_balance` VALUES ('28', '20', '18652169031', '1.01', '0.01', '18652169031', '2', '0', '', 'TB_20180605140207mCvk', '1528178527', '20');
INSERT INTO `tab_balance` VALUES ('29', '20', '18652169031', '1.01', '0.01', '18652169031', '2', '1', '', 'TB_20180605140358vaLu', '1528178638', '20');
INSERT INTO `tab_balance` VALUES ('30', '20', '18652169031', '1.02', '0.01', '18652169031', '1', '1', '', 'TB_20180605140547LZkj', '1528178747', '20');
INSERT INTO `tab_balance` VALUES ('31', '20', '18652169031', '1.03', '0.01', '18652169031', '2', '0', '', 'TB_20180605140805yr0R', '1528178885', '20');
INSERT INTO `tab_balance` VALUES ('32', '20', '18652169031', '1.03', '0.01', '18652169031', '1', '1', '', 'TB_20180605141406lnG9', '1528179246', '20');
INSERT INTO `tab_balance` VALUES ('33', '4', 'asdasd', '593.90', '0.01', 'asdasd', '1', '0', '', 'TB_20180605142509ABI3', '1528179909', '4');
INSERT INTO `tab_balance` VALUES ('34', '20', '18652169031', '1.04', '999999999.99', '18652169031', '1', '0', '', 'TB_201806071031192uob', '1528338679', '20');
INSERT INTO `tab_balance` VALUES ('35', '20', '18652169031', '1.04', '999999999.99', '18652169031', '2', '0', '', 'TB_20180607103135edq4', '1528338695', '20');
INSERT INTO `tab_balance` VALUES ('36', '20', '18652169031', '1.04', '999999999.99', '18652169031', '2', '0', '', 'TB_20180607103200HABB', '1528338720', '20');
INSERT INTO `tab_balance` VALUES ('37', '20', '18652169031', '1.04', '999999999.99', '18652169031', '2', '0', '', 'TB_20180607103214G2SR', '1528338734', '20');
INSERT INTO `tab_balance` VALUES ('38', '20', '18652169031', '1.04', '999999999.99', '18652169031', '2', '0', '', 'TB_20180607103242lQF4', '1528338762', '20');
INSERT INTO `tab_balance` VALUES ('39', '20', '18652169031', '1.04', '999999999.99', '18652169031', '1', '0', '', 'TB_20180607103255B8iQ', '1528338775', '20');
INSERT INTO `tab_balance` VALUES ('40', '20', '18652169031', '1.04', '999999999.99', '18652169031', '2', '0', '', 'TB_20180607103302d3FD', '1528338782', '20');
INSERT INTO `tab_balance` VALUES ('41', '20', '18652169031', '1.04', '11111.00', '18652169031', '1', '0', '', 'TB_201806071035442D5R', '1528338944', '20');
INSERT INTO `tab_balance` VALUES ('42', '20', '18652169031', '1.04', '999999999.99', '18652169031', '1', '0', '', 'TB_20180607103644Oikb', '1528339004', '20');
INSERT INTO `tab_balance` VALUES ('43', '20', '18652169031', '1.04', '123456.00', '18652169031', '2', '0', '', 'TB_20180607103705EW61', '1528339025', '20');
INSERT INTO `tab_balance` VALUES ('44', '20', '18652169031', '1.04', '123456798.00', '18652169031', '2', '0', '', 'TB_20180607103722Rp0s', '1528339042', '20');
INSERT INTO `tab_balance` VALUES ('45', '20', '18652169031', '1.04', '123456798.00', '18652169031', '1', '0', '', 'TB_20180607103837ogvn', '1528339117', '20');
INSERT INTO `tab_balance` VALUES ('46', '20', '18652169031', '1.04', '123456.00', '18652169031', '1', '0', '', 'TB_20180607103855VQ8h', '1528339135', '20');
INSERT INTO `tab_balance` VALUES ('47', '20', '18652169031', '1.04', '123456.00', '18652169031', '1', '0', '', 'TB_20180607103916hGCe', '1528339156', '20');
INSERT INTO `tab_balance` VALUES ('48', '20', '18652169031', '1.04', '123456.00', '18652169031', '2', '0', '', 'TB_20180607103935lRCR', '1528339176', '20');
INSERT INTO `tab_balance` VALUES ('49', '20', '18652169031', '1.04', '999999999.99', '18652169031', '2', '0', '', 'TB_20180607110448Kney', '1528340689', '20');
