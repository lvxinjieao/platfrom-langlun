/*
Navicat MySQL Data Transfer

Source Server         : testh55
Source Server Version : 50557
Source Host           : 121.43.196.29:3306
Source Database       : testh55_vlcms_c

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2018-06-08 17:43:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_action
-- ----------------------------
DROP TABLE IF EXISTS `sys_action`;
CREATE TABLE `sys_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=148 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- ----------------------------
-- Records of sys_action
-- ----------------------------
INSERT INTO `sys_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `sys_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `sys_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `sys_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `sys_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `sys_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '[user|get_nickname]在[time|time_format] 新增或修改或删除配置', '1', '1', '1525759528');
INSERT INTO `sys_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '[user|get_nickname]在[time|time_format] 更新模型', '1', '1', '1525758704');
INSERT INTO `sys_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `sys_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '[user|get_nickname]在[time|time_format] 新增或修改或删除导航', '1', '1', '1525768603');
INSERT INTO `sys_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '[user|get_nickname]在[time|time_format] 新增或修改或删除菜单', '1', '1', '1525759745');
INSERT INTO `sys_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '[user|get_nickname]在[time|time_format] 新增或修改分类信息', '1', '1', '1525759477');
INSERT INTO `sys_action` VALUES ('12', 'admin_change_themes', '后台主题切换', '切换后台主题', '', '[user|get_nickname]在[time|time_format]切换了后台主题:[record]', '1', '1', '1525664030');
INSERT INTO `sys_action` VALUES ('13', 'admin_logout', '后台管理员退出', '管理员退出管理后台', '', '[user|get_nickname]在[time|time_format]退出了后台', '1', '1', '1525664668');
INSERT INTO `sys_action` VALUES ('14', 'save_kuaijie', '快捷图标设置', '设置首页快捷图标', '', '[user|get_nickname]在[time|time_format]设置了快捷图标', '1', '1', '1525672536');
INSERT INTO `sys_action` VALUES ('15', 'update_userinfo', '修改玩家信息', '修改玩家信息', '', '[user|get_nickname]在[time|time_format]修改了[record]的信息', '1', '1', '1525673799');
INSERT INTO `sys_action` VALUES ('16', 'lock_status', '锁定玩家账号', '锁定玩家账号', '', '[user|get_nickname]在[time|time_format]锁定了账号:[record]', '1', '1', '1525674387');
INSERT INTO `sys_action` VALUES ('17', 'unlock_status', '解锁玩家账号', '解除锁定状态的账号', '', '[user|get_nickname]在[time|time_format]解除了[record]的锁定', '1', '1', '1525674379');
INSERT INTO `sys_action` VALUES ('18', 'del_user_login_record', '删除玩家登陆记录', '删除玩家登陆记录', '', '[user|get_nickname]在[time|time_format]删除了[record]的登陆记录', '1', '1', '1525675121');
INSERT INTO `sys_action` VALUES ('19', 'batch_del_user_login_record', '批量删除玩家登陆记录', '批量删除玩家登陆记录', '', '[user|get_nickname]在[time|time_format]批量删除玩家登陆记录', '1', '1', '1525675637');
INSERT INTO `sys_action` VALUES ('20', 'update_real_name_auth', '修改实名认证设置', '修改实名认证设置', '', '[user|get_nickname]在[time|time_format]修改了实名认证设置', '1', '1', '1525676028');
INSERT INTO `sys_action` VALUES ('21', 'add_admin_member', '添加管理员', '添加管理员', '', '[user|get_nickname]在[time|time_format]新增管理员:[record]', '1', '1', '1525677047');
INSERT INTO `sys_action` VALUES ('22', 'update_admin_member', '修改管理员信息', '修改管理员信息', '', '[user|get_nickname]在[time|time_format]修改了管理员 [record] 的信息', '1', '1', '1525677681');
INSERT INTO `sys_action` VALUES ('23', 'lock_admin_member', '锁定后台管理员', '锁定后台管理员', '', '[user|get_nickname]在[time|time_format]锁定了管理员 [record]', '1', '1', '1525679362');
INSERT INTO `sys_action` VALUES ('24', 'unlock_admin_member', '解锁后台管理员', '解锁后台管理员', '', '[user|get_nickname]在[time|time_format]解除了管理员 [record] 的锁定状态', '1', '1', '1525679513');
INSERT INTO `sys_action` VALUES ('25', 'del_admin_member', '删除后台管理员', '删除后台管理员', '', '[user|get_nickname]在[time|time_format]删除了管理员:[record]', '1', '1', '1525680290');
INSERT INTO `sys_action` VALUES ('26', 'add_admin_group', '添加后台用户组', '添加后台用户组', '', '[user|get_nickname]在[time|time_format]新增用户组:[record]', '1', '1', '1525681079');
INSERT INTO `sys_action` VALUES ('27', 'lock_admin_group', '禁用后台用户组', '禁用后台用户组', '', '[user|get_nickname]在[time|time_format]禁用用户组:[record]', '1', '1', '1525681512');
INSERT INTO `sys_action` VALUES ('28', 'unlock_admin_group', '解锁后台用户组', '解锁后台用户组', '', '[user|get_nickname]在[time|time_format]解锁后台用户组:[record]', '1', '1', '1525681957');
INSERT INTO `sys_action` VALUES ('29', 'del_admin_group', '删除后台用户组', '删除后台用户组', '', '[user|get_nickname]在[time|time_format]删除用户组:[record]', '1', '1', '1525682098');
INSERT INTO `sys_action` VALUES ('30', 'update_admin_group', '修改后台用户组', '修改后台用户组', '', '[user|get_nickname]在[time|time_format]编辑用户组:[record]', '1', '1', '1525682953');
INSERT INTO `sys_action` VALUES ('31', 'update_admin_group_access', '修改后台用户组_访问授权', '修改后台用户组_访问授权', '', '[user|get_nickname]在[time|time_format]编辑用户组: [record] 访问授权', '1', '1', '1525683080');
INSERT INTO `sys_action` VALUES ('32', 'update_admin_group_class', '修改后台用户组_分类授权', '修改后台用户组_分类授权', '', '[user|get_nickname]在[time|time_format]编辑用户组: [record] 分类授权', '1', '1', '1525683509');
INSERT INTO `sys_action` VALUES ('33', 'update_admin_group_member', '修改后台用户组_添加成员', '修改后台用户组_添加成员', '', '[user|get_nickname]在[time|time_format]编辑用户组: [record] 添加成员', '1', '1', '1525683928');
INSERT INTO `sys_action` VALUES ('34', 'update_admin_group_del_member', '修改后台用户组_删除成员', '修改后台用户组_删除成员', '', '[user|get_nickname]在[time|time_format]编辑用户组: [record] 删除成员', '1', '1', '1525684343');
INSERT INTO `sys_action` VALUES ('35', 'del_action_log', '删除行为日志', '删除单条行为日志', '', '[user|get_nickname]在[time|time_format]删除行为日志\r\n日志id:[record]', '1', '1', '1525687235');
INSERT INTO `sys_action` VALUES ('36', 'del_action_log_batch', '批量删除行为日志', '批量删除行为日志', '', '[user|get_nickname]在[time|time_format]批量删除行为日志', '1', '1', '1525687363');
INSERT INTO `sys_action` VALUES ('37', 'clear_action_log', '清空行为日志', '清空行为日志', '', '[user|get_nickname]在[time|time_format]清空行为日志', '1', '1', '1525687647');
INSERT INTO `sys_action` VALUES ('38', 'add_busier', '添加商务专员', '添加商务专员', '', '[user|get_nickname]在[time|time_format]添加商务专员 : [record]', '1', '1', '1525689980');
INSERT INTO `sys_action` VALUES ('39', 'edit_busier', '编辑商务专员', '编辑商务专员', '', '[user|get_nickname]在[time|time_format]修改商务专员信息 : [record]', '1', '1', '1525690774');
INSERT INTO `sys_action` VALUES ('40', 'lock__busier', '禁用商务专员', '禁用商务专员', '', '[user|get_nickname]在[time|time_format]禁用商务专员 : [record]', '1', '1', '1525690905');
INSERT INTO `sys_action` VALUES ('41', 'unlock__busier', '解锁商务专员', '解锁商务专员', '', '[user|get_nickname]在[time|time_format]解锁商务专员 : [record]', '1', '1', '1525690932');
INSERT INTO `sys_action` VALUES ('42', 'del_busier', '删除商务专员', '删除商务专员', '', '[user|get_nickname]在[time|time_format]删除商务专员 : [record]', '1', '1', '1525691139');
INSERT INTO `sys_action` VALUES ('43', 'order_budan', '订单补单', '订单补单', '', '[user|get_nickname]在[time|time_format]补单,订单号: [record]', '1', '1', '1525691587');
INSERT INTO `sys_action` VALUES ('44', 'ptb_send_1', '平台币发放_单用户', '平台币发放_单用户', '', '[user|get_nickname]在[time|time_format]给账号[record]发放平台币', '1', '1', '1525691955');
INSERT INTO `sys_action` VALUES ('45', 'ptb_send_2', '平台币批量发放', '平台币批量发放', '', '[user|get_nickname]在[time|time_format]批量发放平台币', '1', '1', '1525692030');
INSERT INTO `sys_action` VALUES ('46', 'del_ptb_send_log', '删除平台币/绑币发放记录', '删除平台币/绑币发放记录', '', '[user|get_nickname]在[time|time_format]删除平台币/绑币发放记录', '1', '1', '1525766433');
INSERT INTO `sys_action` VALUES ('47', 'batch_ptb_chongzhi', '批量平台币充值', '批量平台币充值', '', '[user|get_nickname]在[time|time_format]批量平台币充值', '1', '1', '1525692637');
INSERT INTO `sys_action` VALUES ('48', 'add_fanli', '新增返利设置', '新增返利设置', '', '[user|get_nickname]在[time|time_format]新增返利设置', '1', '1', '1525692934');
INSERT INTO `sys_action` VALUES ('49', 'edit_fanli', '编辑返利设置', '编辑返利设置', '', '[user|get_nickname]在[time|time_format]编辑返利设置', '1', '1', '1525693070');
INSERT INTO `sys_action` VALUES ('50', 'del_fanli', '删除返利设置', '删除返利设置', '', '[user|get_nickname]在[time|time_format]删除返利设置', '1', '1', '1525693153');
INSERT INTO `sys_action` VALUES ('51', 'add_game', '新增游戏', '新增游戏', '', '[user|get_nickname]在[time|time_format]新增游戏 : [record]', '1', '1', '1525693443');
INSERT INTO `sys_action` VALUES ('52', 'edit_game', '编辑游戏', '编辑游戏', '', '[user|get_nickname]在[time|time_format]编辑游戏 : [record]', '1', '1', '1525693552');
INSERT INTO `sys_action` VALUES ('53', 'del_game', '删除游戏', '删除游戏', '', '[user|get_nickname]在[time|time_format]删除游戏 : [record]', '1', '1', '1525693684');
INSERT INTO `sys_action` VALUES ('54', 'del_game_batch', '批量删除游戏', '批量删除游戏', '', '[user|get_nickname]在[time|time_format]批量删除游戏', '1', '1', '1525693898');
INSERT INTO `sys_action` VALUES ('55', 'add_game_type', '新增游戏类型', '新增游戏类型', '', '[user|get_nickname]在[time|time_format]新增游戏类型[record]', '1', '1', '1525694216');
INSERT INTO `sys_action` VALUES ('56', 'edit_game_type', '编辑游戏类型', '编辑游戏类型', '', '[user|get_nickname]在[time|time_format]编辑游戏类型 \r\n: [record]', '1', '1', '1525694462');
INSERT INTO `sys_action` VALUES ('57', 'del_game_type', '删除游戏类型', '删除游戏类型', '', '[user|get_nickname]在[time|time_format]删除游戏类型 : [record]', '1', '1', '1525694761');
INSERT INTO `sys_action` VALUES ('58', 'del_game_type_batch', '批量删除游戏类型', '批量删除游戏类型', '', '[user|get_nickname]在[time|time_format]批量删除游戏类型', '1', '1', '1525694782');
INSERT INTO `sys_action` VALUES ('59', 'add_open_type', '新增运营类型', '新增运营类型', '', '[user|get_nickname]在[time|time_format]新增运营类型:[record]', '1', '1', '1525694988');
INSERT INTO `sys_action` VALUES ('60', 'edit_open_type', '编辑运营状态', '编辑运营状态', '', '[user|get_nickname]在[time|time_format]编辑运营状态 : [record]', '1', '1', '1525695079');
INSERT INTO `sys_action` VALUES ('61', 'del_open_type', '批量删除运营状态', '批量删除运营状态', '', '[user|get_nickname]在[time|time_format]批量删除运营状态', '1', '1', '1525695163');
INSERT INTO `sys_action` VALUES ('62', 'add_server', '添加区服', '添加区服', '', '[user|get_nickname]在[time|time_format]添加游戏[record] 区服', '1', '1', '1525695719');
INSERT INTO `sys_action` VALUES ('63', 'edit_server', '编辑区服', '编辑区服', '', '[user|get_nickname]在[time|time_format]编辑游戏 [record] 区服', '1', '1', '1525695980');
INSERT INTO `sys_action` VALUES ('64', 'del_server', '删除游戏区服', '删除游戏区服', '', '[user|get_nickname]在[time|time_format]删除游戏[record] 区服', '1', '1', '1525696520');
INSERT INTO `sys_action` VALUES ('65', 'del_server_batch', '批量删除游戏区服', '批量删除游戏区服', '', '[user|get_nickname]在[time|time_format]批量删除游戏区服', '1', '1', '1525696542');
INSERT INTO `sys_action` VALUES ('66', 'add_server_batch', '批量新增游戏区服', '批量新增游戏区服', '', '[user|get_nickname]在[time|time_format]批量新增游戏区服', '1', '1', '1525696631');
INSERT INTO `sys_action` VALUES ('67', 'add_giftbag', '添加礼包', '添加礼包', '', '[user|get_nickname]在[time|time_format]添加 [record] 礼包', '1', '1', '1525697513');
INSERT INTO `sys_action` VALUES ('68', 'edit_giftbag', '编辑游戏礼包', '编辑游戏礼包', '', '[user|get_nickname]在[time|time_format]编辑 [record] 礼包', '1', '1', '1525697632');
INSERT INTO `sys_action` VALUES ('69', 'del_giftbag', '删除游戏礼包', '删除游戏礼包', '', '[user|get_nickname]在[time|time_format]删除 [record] 礼包', '1', '1', '1525741677');
INSERT INTO `sys_action` VALUES ('70', 'del_giftbag_batch', '批量删除游戏礼包', '批量删除游戏礼包', '', '[user|get_nickname]在[time|time_format]批量删除游戏礼包', '1', '1', '1525741702');
INSERT INTO `sys_action` VALUES ('71', 'add_promote', '新增推广员', '新增推广员', '', '[user|get_nickname]在[time|time_format] 新增推广员 [record]', '1', '1', '1525742147');
INSERT INTO `sys_action` VALUES ('72', 'edit_promote', '编辑推广员', '编辑推广员', '', '[user|get_nickname]在[time|time_format]编辑推广员 [record]', '1', '1', '1525742713');
INSERT INTO `sys_action` VALUES ('73', 'lock_promote', '锁定推广员', '锁定推广员', '', '[user|get_nickname]在[time|time_format]锁定推广员', '1', '1', '1525743478');
INSERT INTO `sys_action` VALUES ('74', 'unlock_promote', '解锁/审核推广员', '解锁/审核推广员', '', '[user|get_nickname]在[time|time_format]解锁/审核推官员', '1', '1', '1525743505');
INSERT INTO `sys_action` VALUES ('75', 'close_auto_audit', '关闭全站推广员自动审核', '关闭全站推广员自动审核', '', '[user|get_nickname]在[time|time_format] 关闭全站推广员自动审核', '1', '1', '1525743842');
INSERT INTO `sys_action` VALUES ('76', 'open_auto_audit', '开启全站推广员自动审核', '开启全站推广员自动审核', '', '[user|get_nickname]在[time|time_format] 开启全站推广员自动审核', '1', '1', '1525743872');
INSERT INTO `sys_action` VALUES ('77', 'audit_apply_union', '全站推广申请批量审核', '全站推广申请批量审核', '', '[user|get_nickname]在[time|time_format] 全站推广申请批量审核', '1', '1', '1525744799');
INSERT INTO `sys_action` VALUES ('78', 'close_game_auto_audit', '关闭全站/游戏推广自动审核', '关闭全站/游戏推广自动审核', '', '[user|get_nickname]在[time|time_format] 关闭全站/游戏推广自动审核', '1', '1', '1525745238');
INSERT INTO `sys_action` VALUES ('79', 'open_game_auto_audit', '开启游戏/全站推广自动审核', '开启游戏/全站推广自动审核', '', '[user|get_nickname]在[time|time_format] 开启游戏/全站推广自动审核', '1', '1', '1525745271');
INSERT INTO `sys_action` VALUES ('80', 'del_applyunion_batch', '批量删除全站推广申请', '批量删除全站推广申请', '', '[user|get_nickname]在[time|time_format] 批量删除全站推广申请', '1', '1', '1525745512');
INSERT INTO `sys_action` VALUES ('81', 'audit_game_link', '审核游戏推广链接', '审核游戏推广链接', '', '[user|get_nickname]在[time|time_format] 审核游戏推广链接', '1', '1', '1525745937');
INSERT INTO `sys_action` VALUES ('82', 'mend_edit', '推广补链', '推广补链', '', '[user|get_nickname]在[time|time_format] 操作推广补链, 用户 : [record]', '1', '1', '1525746612');
INSERT INTO `sys_action` VALUES ('83', 'app_audit', '批量审核APP打包', '批量审核APP打包', '', '[user|get_nickname]在[time|time_format]  批量审核APP打包', '1', '1', '1525746921');
INSERT INTO `sys_action` VALUES ('84', 'app_dabao', 'APP打包', 'APP打包', '', '[user|get_nickname]在[time|time_format] APP打包', '1', '1', '1525747013');
INSERT INTO `sys_action` VALUES ('85', 'app_del', '批量删除APP分包申请', '批量删除APP分包申请', '', '[user|get_nickname]在[time|time_format] 批量删除APP分包申请', '1', '1', '1525747107');
INSERT INTO `sys_action` VALUES ('86', 'set_check_status_2', '设置玩家不参与结算', '设置玩家不参与结算', '', '[user|get_nickname]在[time|time_format] 设置玩家 [record] 不参与结算', '1', '1', '1525747713');
INSERT INTO `sys_action` VALUES ('87', 'set_check_status_1', '设置玩家参与结算', '设置玩家参与结算', '', '[user|get_nickname]在[time|time_format] 设置玩家 [record] 参与结算', '1', '1', '1525747715');
INSERT INTO `sys_action` VALUES ('88', 'save_config', '修改站点配置', '修改站点配置', '', '[user|get_nickname]在[time|time_format] 修改站点配置', '1', '1', '1525748206');
INSERT INTO `sys_action` VALUES ('89', 'update_source', '更新游戏原包', '更新游戏原包', '', '[user|get_nickname]在[time|time_format] 更新游戏原包', '1', '1', '1525748457');
INSERT INTO `sys_action` VALUES ('90', 'add_media_adv', '添加广告', '添加广告', '', '[user|get_nickname]在[time|time_format] 添加广告', '1', '1', '1525748878');
INSERT INTO `sys_action` VALUES ('91', 'del_adv', '删除广告', '删除广告', '', '[user|get_nickname]在[time|time_format] 删除广告', '1', '1', '1525749020');
INSERT INTO `sys_action` VALUES ('92', 'save_seo', '修改seo设置', '修改seo设置', '', '[user|get_nickname]在[time|time_format] 修改seo设置', '1', '1', '1525749127');
INSERT INTO `sys_action` VALUES ('93', 'links_add', '添加友情链接', '添加友情链接', '', '[user|get_nickname]在[time|time_format] 添加友情链接', '1', '1', '1525749298');
INSERT INTO `sys_action` VALUES ('94', 'del_links', '删除友情链接', '删除友情链接', '', '[user|get_nickname]在[time|time_format] 删除友情链接', '1', '1', '1525749412');
INSERT INTO `sys_action` VALUES ('95', 'add_kefu', '新增客服文档', '新增客服文档', '', '[user|get_nickname]在[time|time_format] 新增客服文档', '1', '1', '1525749571');
INSERT INTO `sys_action` VALUES ('96', 'update_Kefuquestion', '编辑客服文档', '编辑客服问题', '', '[user|get_nickname]在[time|time_format] 编辑客服文档', '1', '1', '1525749718');
INSERT INTO `sys_action` VALUES ('97', 'update_article', '更新官网文章', '更新官网文章', '', '[user|get_nickname]在[time|time_format] 更新官网文章', '1', '1', '1525750970');
INSERT INTO `sys_action` VALUES ('98', 'add_web_article', '发布官网文章', '发布官网文章', '', '[user|get_nickname]在[time|time_format] 发布官网文章', '1', '1', '1525750982');
INSERT INTO `sys_action` VALUES ('99', 'save_tool', '系统-扩展工具配置', '系统-扩展工具配置', '', '[user|get_nickname]在[time|time_format] 系统-扩展工具配置', '1', '1', '1525760666');
INSERT INTO `sys_action` VALUES ('100', 'edit_pointtype', '更新积分设置', '更新积分设置', '', '[user|get_nickname]在[time|time_format] 更新积分设置', '1', '1', '1525751267');
INSERT INTO `sys_action` VALUES ('101', 'add_point_shop', '添加积分商品', '添加积分商品', '', '[user|get_nickname]在[time|time_format] 添加积分商品', '1', '1', '1525751413');
INSERT INTO `sys_action` VALUES ('102', 'edit_point_shop', '编辑积分商品', '编辑积分商品', '', '[user|get_nickname]在[time|time_format] 编辑积分商品', '1', '1', '1525751500');
INSERT INTO `sys_action` VALUES ('103', 'del_point_shop', '删除积分商品', '删除积分商品', '', '[user|get_nickname]在[time|time_format] 删除积分商品', '1', '1', '1525751534');
INSERT INTO `sys_action` VALUES ('104', 'push_add', '新增推送设置', '新增推送设置', '', '[user|get_nickname]在[time|time_format] 新增推送设置', '1', '1', '1525751621');
INSERT INTO `sys_action` VALUES ('105', 'push_edit', '更新推送设置', '更新推送设置', '', '[user|get_nickname]在[time|time_format] 更新推送设置', '1', '1', '1525751695');
INSERT INTO `sys_action` VALUES ('106', 'push_del', '删除推送设置', '删除推送设置', '', '[user|get_nickname]在[time|time_format] 删除推送设置', '1', '1', '1525751753');
INSERT INTO `sys_action` VALUES ('107', 'set_language', '设置语言', '设置语言', '', '[user|get_nickname]在[time|time_format] 设置语言', '1', '1', '1525757552');
INSERT INTO `sys_action` VALUES ('108', 'add_push_list', '新增发送通知', '新增发送通知', '', '[user|get_nickname]在[time|time_format] 新增发送通知', '1', '1', '1525757662');
INSERT INTO `sys_action` VALUES ('109', 'del_push_list', '删除发送通知', '删除发送通知', '', '[user|get_nickname]在[time|time_format] 删除发送通知', '1', '1', '1525757726');
INSERT INTO `sys_action` VALUES ('110', 'add_model', '更新模型', '新建模型', '', '[user|get_nickname]在[time|time_format] 新建模型', '1', '1', '1525758741');
INSERT INTO `sys_action` VALUES ('111', 'add_Kuaijieicon', '新增快捷图标', '新增快捷图标', '', '[user|get_nickname]在[time|time_format] 新增快捷图标', '1', '1', '1525760059');
INSERT INTO `sys_action` VALUES ('112', 'edit_Kuaijieicon', '修改快捷图标', '修改快捷图标', '', '[user|get_nickname]在[time|time_format] 修改快捷图标', '1', '1', '1525760153');
INSERT INTO `sys_action` VALUES ('113', 'del_Kuaijieicon', '删除快捷图标', '删除快捷图标', '', '[user|get_nickname]在[time|time_format] 删除快捷图标', '1', '1', '1525760180');
INSERT INTO `sys_action` VALUES ('114', 'save_jubaobar', '动态密保设置', '动态密保设置', '', '[user|get_nickname]在[time|time_format] 动态密保设置', '1', '1', '1525760398');
INSERT INTO `sys_action` VALUES ('115', 'add_route', '添加路由', '添加路由', '', '[user|get_nickname]在[time|time_format] 添加路由', '1', '1', '1525760794');
INSERT INTO `sys_action` VALUES ('116', 'edit_route', '编辑路由', '编辑路由', '', '[user|get_nickname]在[time|time_format] 编辑路由', '1', '1', '1525761225');
INSERT INTO `sys_action` VALUES ('117', 'del_route', '删除路由', '删除路由', '', '[user|get_nickname]在[time|time_format] 删除路由', '1', '1', '1525761261');
INSERT INTO `sys_action` VALUES ('118', 'add_addons', '新增插件', '新增插件', '', '[user|get_nickname]在[time|time_format] 新增插件', '1', '1', '1525761679');
INSERT INTO `sys_action` VALUES ('119', 'open_addons', '启用插件', '启用插件', '', '[user|get_nickname]在[time|time_format] 启用插件', '1', '1', '1525761759');
INSERT INTO `sys_action` VALUES ('120', 'edit_addons', '更新插件', '更新插件', '', '[user|get_nickname]在[time|time_format] 更新插件', '1', '1', '1525761851');
INSERT INTO `sys_action` VALUES ('121', 'add_hook', '新增钩子', '新增钩子', '', '[user|get_nickname]在[time|time_format] 新增钩子', '1', '1', '1525762168');
INSERT INTO `sys_action` VALUES ('122', 'edit_hook', '编辑钩子', '编辑钩子', '', '[user|get_nickname]在[time|time_format] 编辑钩子', '1', '1', '1525762193');
INSERT INTO `sys_action` VALUES ('123', 'del_hook', '删除钩子', '删除钩子', '', '[user|get_nickname]在[time|time_format] 删除钩子', '1', '1', '1525762383');
INSERT INTO `sys_action` VALUES ('124', 'ptb_send_tg', '平台币发放(推广员)', '平台币发放(推广员)', '', '[user|get_nickname]在[time|time_format] 平台币发放(推广员) : [record]', '1', '1', '1525763336');
INSERT INTO `sys_action` VALUES ('125', 'ptb_recycle', '平台币回收(玩家)', '平台币回收(玩家)', '', '[user|get_nickname]在[time|time_format] 平台币回收(玩家) : [record]', '1', '1', '1525763820');
INSERT INTO `sys_action` VALUES ('126', 'ptb_recycle_tg', '平台币回收(推广员)', '平台币回收(推广员)', '', '[user|get_nickname]在[time|time_format] 平台币回收(推广员) : [record]', '1', '1', '1525763850');
INSERT INTO `sys_action` VALUES ('128', 'bdptb_send_1', '绑币发放_单用户', '绑币发放_单用户', '', '[user|get_nickname]在[time|time_format]给账号[record]发放绑币', '1', '1', '1525765448');
INSERT INTO `sys_action` VALUES ('129', 'bdptb_send_2', '绑币批量发放', '绑币批量发放', '', '[user|get_nickname]在[time|time_format]批量发放绑币', '1', '1', '1525765492');
INSERT INTO `sys_action` VALUES ('130', 'bdptb_recycle', '绑币回收', '绑币回收', '', '[user|get_nickname]在[time|time_format] 绑币回收', '1', '1', '1525765926');
INSERT INTO `sys_action` VALUES ('131', 'tg_jiesuan', '推广结算', '推广结算', '', '[user|get_nickname]在[time|time_format]  推广结算 \r\n推广员 : [record]', '1', '1', '1525767879');
INSERT INTO `sys_action` VALUES ('132', 'tg_tx_agree', '同意推广提现', '同意推广提现', '', '[user|get_nickname]在[time|time_format]  同意推广提现', '1', '1', '1525768294');
INSERT INTO `sys_action` VALUES ('133', 'tg_tx_disagree', '拒绝推广提现', '拒绝推广提现', '', '[user|get_nickname]在[time|time_format] 拒绝推广提现', '1', '1', '1525768311');
INSERT INTO `sys_action` VALUES ('134', 'pl_del_fanli', '批量删除返利设置', '批量删除返利设置', '', '[user|get_nickname]在[time|time_format] 批量删除返利设置', '1', '1', '1527561655');
INSERT INTO `sys_action` VALUES ('135', 'del_apply', '删除推广链接', '删除推广链接', '', '[user|get_nickname]在[time|time_format] 删除推广链接', '1', '1', '1527562605');
INSERT INTO `sys_action` VALUES ('136', 'links_edit', '编辑友情链接', '修改友情链接', '', '[user|get_nickname]在[time|time_format] 修改友情链接', '1', '1', '1527565199');
INSERT INTO `sys_action` VALUES ('137', 'pl_del_links', '批量删除友情链接', '批量删除友情链接', '', '[user|get_nickname]在[time|time_format] 批量删除友情链接', '1', '1', '1527565869');
INSERT INTO `sys_action` VALUES ('138', 'edit_media_adv', '编辑广告', '编辑广告', '', '[user|get_nickname]在[time|time_format] 编辑广告', '1', '1', '1527573322');
INSERT INTO `sys_action` VALUES ('139', 'pl_del_adv', '批量删除广告', '批量删除广告', '', '[user|get_nickname]在[time|time_format] 批量删除广告', '1', '1', '1527574516');
INSERT INTO `sys_action` VALUES ('140', 'del_Kefuquestion', '删除客服文档', '删除客服文档', '', '[user|get_nickname]在[time|time_format] 删除客服文档', '1', '1', '1527577076');
INSERT INTO `sys_action` VALUES ('141', 'pl_del_web_article', '批量删除官网文章', '批量删除官网文章', '', '[user|get_nickname]在[time|time_format] 批量删除官网文章', '1', '1', '1527577676');
INSERT INTO `sys_action` VALUES ('142', 'del_web_article', '删除官网文章', '删除官网文章', '', '[user|get_nickname]在[time|time_format] 删除官网文章', '1', '1', '1527577702');
INSERT INTO `sys_action` VALUES ('143', 'pl_push_del', '批量删除推送设置', '批量删除推送设置', '', '[user|get_nickname]在[time|time_format] 批量删除推送设置', '1', '1', '1527578215');
INSERT INTO `sys_action` VALUES ('144', 'add_dczk', '新增代充折扣', '新增代充折扣', '', '[user|get_nickname]在[time|time_format] 新增代充折扣', '1', '1', '1527850961');
INSERT INTO `sys_action` VALUES ('145', 'edit_dczk', '编辑代充折扣', '编辑代充折扣', '', '[user|get_nickname]在[time|time_format] 编辑代充折扣', '1', '1', '1527851004');
INSERT INTO `sys_action` VALUES ('146', 'del_dczk', '删除代充折扣', '删除代充折扣', '', '[user|get_nickname]在[time|time_format] 删除代充折扣', '1', '1', '1527851048');
INSERT INTO `sys_action` VALUES ('147', 'pl_del_dczk', '批量删除代充折扣', '批量删除代充折扣', '', '[user|get_nickname]在[time|time_format] 批量删除代充折扣', '1', '1', '1527851099');
